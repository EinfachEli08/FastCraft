#pragma once
#include <random>

class Math
{
public:
    static double random();                              
    static constexpr double PI = 3.14159265358979323846; 
};
