#ifndef OPENGLHEADERS_H
#define OPENGLHEADERS_H

#define GLFW_INCLUDE_NONE
#include <glad/glad.h>
#include <GLFW/glfw3.h>

#endif