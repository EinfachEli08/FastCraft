class HitResult
{
public:
    int x;
    int y;
    int z;
    int o;
    int f;

    // Constructor
    HitResult(int x, int y, int z, int o, int f)
        : x(x), y(y), z(z), o(o), f(f) {}
};
