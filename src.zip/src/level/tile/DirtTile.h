#pragma once
#include "level/tile/Tile.h"

class DirtTile : public Tile
{
public:
    DirtTile(int id, int tex);
};
