#include "DirtTile.h"

DirtTile::DirtTile(int id, int tex) : Tile(id, tex) {}
